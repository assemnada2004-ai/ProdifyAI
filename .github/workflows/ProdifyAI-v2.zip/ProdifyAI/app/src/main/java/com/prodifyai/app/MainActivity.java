package com.prodifyai.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.*;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(7, 11, 30);
    private final int CARD = Color.rgb(16, 22, 48);
    private final int CARD2 = Color.rgb(21, 28, 60);
    private final int WHITE = Color.WHITE;
    private final int MUTED = Color.rgb(168, 177, 205);
    private final int PURPLE = Color.rgb(124, 58, 237);
    private final int BLUE = Color.rgb(37, 211, 255);
    private final int PINK = Color.rgb(217, 70, 239);
    private Uri selectedImage;
    private LinearLayout currentContent;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);
        showHome();
    }

    private GradientDrawable rounded(int color, float radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius);
        return d;
    }

    private GradientDrawable gradient(int c1, int c2, float radius) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{c1, c2});
        d.setCornerRadius(radius); return d;
    }

    private TextView tv(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.create("sans", Typeface.BOLD));
        return t;
    }

    private Button action(String label) {
        Button b = new Button(this);
        b.setText(label); b.setTextColor(WHITE); b.setTextSize(15); b.setAllCaps(false);
        b.setTypeface(Typeface.create("sans", Typeface.BOLD));
        b.setBackground(gradient(PURPLE, PINK, 60));
        b.setPadding(12, 0, 12, 0);
        return b;
    }

    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l;
    }

    private LinearLayout horizontal() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL); return l;
    }

    private TextView label(String s) {
        TextView t = tv(s, 13, MUTED, false); t.setPadding(0, 14, 0, 7); return t;
    }

    private void base(String title, String subtitle) {
        LinearLayout root = vertical(); root.setBackgroundColor(BG);
        root.setPadding(18, 14, 18, 0);
        LinearLayout top = horizontal();
        TextView mark = tv("P✦", 20, WHITE, true); mark.setGravity(Gravity.CENTER);
        mark.setBackground(gradient(PURPLE, BLUE, 18));
        top.addView(mark, new LinearLayout.LayoutParams(46, 46));
        LinearLayout names = vertical(); names.setPadding(12, 0, 0, 0);
        names.addView(tv("Prodify AI", 18, WHITE, true));
        names.addView(tv("AI PRODUCT STUDIO", 9, MUTED, true));
        top.addView(names, new LinearLayout.LayoutParams(0, 50, 1));
        TextView menu = tv("⋮", 28, WHITE, true); menu.setGravity(Gravity.CENTER);
        top.addView(menu, new LinearLayout.LayoutParams(42, 50));
        root.addView(top, new LinearLayout.LayoutParams(-1, 58));

        LinearLayout header = vertical(); header.setPadding(2, 18, 2, 10);
        header.addView(tv(title, 27, WHITE, true));
        if (subtitle != null) header.addView(tv(subtitle, 14, MUTED, false));
        root.addView(header);

        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        currentContent = vertical(); currentContent.setPadding(0, 4, 0, 28); scroll.addView(currentContent);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    private LinearLayout getContentFromRoot() { return currentContent; }

    private void addBottomNav(LinearLayout content) {
        LinearLayout nav = horizontal(); nav.setPadding(8, 8, 8, 8); nav.setBackground(rounded(CARD, 28));
        String[] items = {"⌂\nالرئيسية", "＋\nإنشاء", "▣\nمشاريعي", "◉\nحسابي"};
        for (String item : items) {
            TextView n = tv(item, 11, MUTED, true); n.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, 62, 1); p.setMargins(3,0,3,0); nav.addView(n,p);
        }
        content.addView(nav, new LinearLayout.LayoutParams(-1, 70));
    }

    private void showHome() {
        base("حوّل منتجك إلى إعلان", "صورة واحدة تكفي. خلّي الذكاء الاصطناعي يجهز لك الباقي.");
        LinearLayout c = getContentFromRoot();

        LinearLayout hero = vertical(); hero.setPadding(20, 20, 20, 20); hero.setBackground(gradient(Color.rgb(28,18,70), Color.rgb(12,48,75), 28));
        TextView badge = tv("✦  AI PRODUCT STUDIO", 11, Color.rgb(222,210,255), true); hero.addView(badge);
        TextView h = tv("صورة منتجك.\nإعلان احترافي.", 29, WHITE, true); h.setPadding(0, 12, 0, 7); hero.addView(h);
        TextView d = tv("ارفع صورة منتجك واختار النمط، وهنجهز لك تصميم تسويقي جاهز للنشر.", 14, Color.rgb(210,216,235), false); d.setLineSpacing(0,1.12f); hero.addView(d);
        Button upload = action("✨   ابدأ بصورة منتج"); upload.setOnClickListener(v -> pickImage());
        LinearLayout.LayoutParams up = new LinearLayout.LayoutParams(-1, 54); up.setMargins(0,18,0,0); hero.addView(upload, up);
        c.addView(hero, new LinearLayout.LayoutParams(-1, 285));

        TextView quick = tv("اختار قالب سريع", 18, WHITE, true); quick.setPadding(2, 22, 0, 10); c.addView(quick);
        LinearLayout row1 = horizontal();
        addTemplate(row1, "🛍️", "متجر", "منتج + سعر"); addTemplate(row1, "👟", "أحذية", "ستايل رياضي");
        c.addView(row1, new LinearLayout.LayoutParams(-1, 105));
        LinearLayout row2 = horizontal();
        addTemplate(row2, "🌸", "عطور", "فاخر وناعم"); addTemplate(row2, "⌚", "إكسسوارات", "Premium");
        c.addView(row2, new LinearLayout.LayoutParams(-1, 105));

        LinearLayout stats = horizontal(); stats.setPadding(16, 12, 16, 12); stats.setBackground(rounded(CARD, 22));
        addStat(stats,"⚡","سريع","تجهيز التصميم"); addStat(stats,"✦","AI","قوالب ذكية"); addStat(stats,"↗","جاهز","للسوشيال");
        c.addView(stats, new LinearLayout.LayoutParams(-1, 82));
        TextView note = tv("نسخة تجريبية — محرك توليد الصور الحقيقي سيتم توصيله في المرحلة التالية.", 11, MUTED, false); note.setGravity(Gravity.CENTER); note.setPadding(0,14,0,4); c.addView(note);
        addBottomNav(c);
    }

    private void addTemplate(LinearLayout row, String icon, String name, String sub) {
        LinearLayout card = vertical(); card.setPadding(14,10,14,8); card.setBackground(rounded(CARD,22));
        TextView a=tv(icon,24,WHITE,false); card.addView(a); card.addView(tv(name,14,WHITE,true)); card.addView(tv(sub,10,MUTED,false));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0, -1,1); p.setMargins(4,0,4,0); row.addView(card,p);
        card.setOnClickListener(v -> pickImage());
    }

    private void addStat(LinearLayout row,String icon,String title,String sub){
        LinearLayout s=vertical(); s.setGravity(Gravity.CENTER); TextView i=tv(icon,17,WHITE,true); i.setGravity(Gravity.CENTER); s.addView(i); TextView t=tv(title,11,WHITE,true); t.setGravity(Gravity.CENTER); s.addView(t); TextView d=tv(sub,9,MUTED,false); d.setGravity(Gravity.CENTER); s.addView(d); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1);row.addView(s,p);
    }

    private void pickImage() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("image/*"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i, 77);
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request,result,data);
        if(request==77 && result==RESULT_OK && data!=null){ selectedImage=data.getData(); showEditor(); }
    }

    private void showEditor(){
        base("إنشاء إعلان", "جهّز تفاصيل التصميم قبل التوليد."); LinearLayout c=getContentFromRoot();
        LinearLayout previewCard=vertical(); previewCard.setPadding(10,10,10,10); previewCard.setBackground(rounded(CARD,24));
        ImageView image=new ImageView(this); image.setImageURI(selectedImage); image.setScaleType(ImageView.ScaleType.CENTER_CROP); image.setBackground(rounded(Color.rgb(9,13,28),20));
        previewCard.addView(image,new LinearLayout.LayoutParams(-1,260));
        TextView change=tv("تغيير الصورة",13,Color.rgb(206,190,255),true); change.setGravity(Gravity.CENTER); change.setPadding(0,10,0,2); change.setOnClickListener(v->pickImage()); previewCard.addView(change,new LinearLayout.LayoutParams(-1,38));
        c.addView(previewCard);

        c.addView(label("نوع الإعلان"));
        LinearLayout styles=horizontal(); String[] st={"متجر","فاخر","عرض","سوشيال"};
        for(String x:st){ TextView chip=tv(x,12,WHITE,true); chip.setGravity(Gravity.CENTER); chip.setBackground(rounded(CARD2,30)); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,48,1);p.setMargins(3,0,3,0);styles.addView(chip,p); chip.setOnClickListener(v->{ for(int j=0;j<styles.getChildCount();j++) styles.getChildAt(j).setBackground(rounded(CARD2,30)); chip.setBackground(gradient(PURPLE,PINK,30)); }); }
        c.addView(styles,new LinearLayout.LayoutParams(-1,54));

        c.addView(label("اسم المنتج")); EditText name=input("مثال: عطر رجالي Premium"); c.addView(name,new LinearLayout.LayoutParams(-1,54));
        c.addView(label("السعر (اختياري)")); EditText price=input("مثال: 499 جنيه"); c.addView(price,new LinearLayout.LayoutParams(-1,54));
        c.addView(label("وصف أو فكرة الإعلان")); EditText prompt=input("مثال: خلفية سوداء فاخرة مع إضاءة ذهبية"); prompt.setGravity(Gravity.TOP|Gravity.RIGHT); prompt.setPadding(16,12,16,12); c.addView(prompt,new LinearLayout.LayoutParams(-1,88));
        Button make=action("✦   جهّز التصميم"); LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,56);mp.setMargins(0,18,0,10);c.addView(make,mp); make.setOnClickListener(v->showResult(name.getText().toString(),price.getText().toString(),prompt.getText().toString()));
        TextView back=tv("← رجوع",13,MUTED,true); back.setGravity(Gravity.CENTER); back.setOnClickListener(v->showHome()); c.addView(back,new LinearLayout.LayoutParams(-1,44));
    }

    private EditText input(String hint){ EditText e=new EditText(this); e.setHint(hint);e.setHintTextColor(Color.rgb(110,121,153));e.setTextColor(WHITE);e.setTextSize(14);e.setSingleLine();e.setBackground(rounded(CARD,18));e.setPadding(16,0,16,0);return e; }

    private void showResult(String name,String price,String prompt){
        base("معاينة الإعلان", "راجع النتيجة قبل الحفظ أو المشاركة."); LinearLayout c=getContentFromRoot();
        LinearLayout ad=vertical(); ad.setBackground(rounded(Color.WHITE,24)); ad.setPadding(10,10,10,14);
        FrameLayout frame=new FrameLayout(this); ImageView image=new ImageView(this); image.setImageURI(selectedImage); image.setScaleType(ImageView.ScaleType.CENTER_CROP); frame.addView(image,new FrameLayout.LayoutParams(-1,390));
        TextView tag=tv("PRODIFY AI",11,WHITE,true);tag.setGravity(Gravity.CENTER);tag.setBackground(rounded(PURPLE,30));FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(112,36,Gravity.TOP|Gravity.RIGHT);tp.setMargins(0,14,14,0);frame.addView(tag,tp); ad.addView(frame,new LinearLayout.LayoutParams(-1,390));
        TextView title=tv(name.length()>0?name:"منتجك الجديد",22,Color.rgb(12,16,34),true); title.setGravity(Gravity.CENTER); title.setPadding(6,12,6,2);ad.addView(title);
        if(price.length()>0){ TextView pr=tv(price,17,PURPLE,true);pr.setGravity(Gravity.CENTER);ad.addView(pr,new LinearLayout.LayoutParams(-1,32)); }
        TextView desc=tv(prompt.length()>0?prompt:"تصميم إعلاني احترافي جاهز للنشر",12,Color.rgb(86,94,116),false);desc.setGravity(Gravity.CENTER);ad.addView(desc);
        c.addView(ad,new LinearLayout.LayoutParams(-1,-2));
        TextView status=tv("هذه معاينة محلية للواجهة. التوليد بالـAI الحقيقي سيستبدل الصورة الأصلية بنتيجة مولّدة.",11,MUTED,false);status.setGravity(Gravity.CENTER);status.setPadding(8,14,8,10);c.addView(status);
        LinearLayout buttons=horizontal(); Button share=action("↗  مشاركة"); Button again=action("＋  تصميم جديد"); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,56,1);bp.setMargins(3,0,3,0);buttons.addView(share,bp);buttons.addView(again,new LinearLayout.LayoutParams(0,56,1));c.addView(buttons,new LinearLayout.LayoutParams(-1,60));
        share.setOnClickListener(v->shareImage()); again.setOnClickListener(v->showHome());
    }

    private void shareImage(){
        if(selectedImage==null){Toast.makeText(this,"اختار صورة أولاً",Toast.LENGTH_SHORT).show();return;}
        Intent send=new Intent(Intent.ACTION_SEND);send.setType("image/*");send.putExtra(Intent.EXTRA_STREAM,selectedImage);startActivity(Intent.createChooser(send,"مشاركة صورة المنتج"));
    }
}
