# Prodify AI

Android application for turning ordinary product photos into marketing-ready visuals.

## Current v1
- Arabic-first interface
- Product image selection
- Ad style selection
- Product/ad description fields
- Preview/result screen
- Android SDK 36 / target SDK 36
- No AI API key embedded in the app

## Build APK with GitHub Actions
1. Create a GitHub repository.
2. Upload the contents of this `ProdifyAI` folder to the repository's `main` branch.
3. Open **Actions** → **Build Prodify AI APK**.
4. Run the workflow with **Run workflow** (or push to `main`).
5. Open the completed run and download the artifact named **ProdifyAI-debug-apk**.
6. Inside the downloaded artifact, install `app-debug.apk` on an Android phone.

## Next development step
Connect the Generate button to a secure backend/AI image-generation service. API secrets must stay on the server and never be shipped inside the APK.
